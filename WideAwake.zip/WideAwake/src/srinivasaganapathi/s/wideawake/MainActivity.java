package srinivasaganapathi.s.wideawake;

import android.media.AudioManager;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import  android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
 
public class MainActivity extends Activity implements OnClickListener {
	 Button bt1,bt2;
	 
		
    @SuppressLint("NewApi") @Override
   
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar acb=getActionBar();
		acb.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#3b5998")));
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        Button start = (Button) findViewById(R.id.button1);
        Button end = (Button) findViewById(R.id.button2);
        Button bt1=(Button) findViewById(R.id.button3);
        Button bt2=(Button) findViewById(R.id.button4);
        bt2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent myIntent = new Intent(arg0.getContext(), Aware.class);
				startActivity(myIntent);
				
			}
		});
        bt1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent myIntent = new Intent(v.getContext(), Aboutus.class);
				startActivity(myIntent);
			}
		});
        start.setOnClickListener(this);
        end.setOnClickListener(this);
    }
 @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        Intent intent = new Intent(getApplicationContext(), MyService.class);
        switch (v.getId()) {
        case R.id.button1:
            intent.putExtra("Start", "1");
            startService(intent);
            break;
        case R.id.button2:
            intent.putExtra("Start", "2");
            startService(intent);
            break;
 
        }
    }
 
}
