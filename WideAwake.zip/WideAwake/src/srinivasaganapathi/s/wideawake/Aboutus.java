package srinivasaganapathi.s.wideawake;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;


public class Aboutus extends Activity {

	Button bn;
	TextView tv1;
    String ret = "";
    private static final String TAG = MainActivity.class.getName();
	@SuppressLint("NewApi") @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_aboutus);
		ActionBar acb=getActionBar();
		acb.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#3b5998")));
		tv1=(TextView) findViewById(R.id.textView1);
		InputStream im= getResources().openRawResource(R.raw.help);
		
		if(im != null)
		{
		InputStreamReader inputStreamReader = new InputStreamReader(im);
		BufferedReader br = new BufferedReader(inputStreamReader);
		 String receiveString = "";
		 StringBuilder stringBuilder = new StringBuilder();
		try{
			
			  while ( (receiveString = br.readLine()) != null ) {
                    stringBuilder.append(receiveString+"\n");
                }
			  im.close();
                ret = stringBuilder.toString();
		}
		
		catch (FileNotFoundException e) {
            Log.e(TAG, "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e(TAG, "Can not read file: " + e.toString());
        }
 tv1.setText(ret);
		            }	
	    
	    
	}

	

}
