package srinivasaganapathi.s.wideawake;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.BatteryManager;
import android.os.IBinder;
import android.os.Vibrator;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class MyService extends Service {
	boolean isCharging;
	public MediaPlayer mp;

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public class TeleListener extends PhoneStateListener {
		public void onCallStateChanged(int state, String incomingNumber) {
			super.onCallStateChanged(state, incomingNumber);
			switch (state) {
			case TelephonyManager.CALL_STATE_IDLE:
				// CALL_STATE_IDLE;

				break;
			case TelephonyManager.CALL_STATE_OFFHOOK:
				// CALL_STATE_OFFHOOK;
				determineChargingState();
				if (isCharging) {
					Vibrator vi = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
					int i = 0;

					while (isCharging == true && i < 7) {
						determineChargingState();
						vi.vibrate(700);
						i++;
						try {
							Thread.sleep(800);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}

					}

					Toast.makeText(getApplicationContext(),
							"Unplug Charger to STOP vibration",
							Toast.LENGTH_LONG).show();
				}
				break;
			case TelephonyManager.CALL_STATE_RINGING:
				// CALL_STATE_RINGING
				determineChargingState();
				AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
				switch (am.getRingerMode()) {
				case AudioManager.RINGER_MODE_SILENT:
					if (isCharging) {
						Vibrator vi = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
						vi.vibrate(700);

					}
					break;
				case AudioManager.RINGER_MODE_VIBRATE:
					if (isCharging) {
						Toast.makeText(getApplicationContext(),
								"Please Stop Charging", Toast.LENGTH_LONG)
								.show();

						try {
							Thread.sleep(500);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						Toast.makeText(getApplicationContext(),
								"Please Stop Charging", Toast.LENGTH_LONG)
								.show();

					}
					break;
				case AudioManager.RINGER_MODE_NORMAL:
					if (isCharging) {

						if (mp != null) {
							mp.release();
						}
						int resId = R.raw.b;
						mp = MediaPlayer.create(getApplicationContext(), resId);
						mp.start();
					}
				}
				break;
			}
		}
	}

	public void determineChargingState() {
		IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		Intent batteryStatus = registerReceiver(null, ifilter);
		// Are we charging / charged?
		int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
		isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
				|| status == BatteryManager.BATTERY_STATUS_FULL;
	}

	@SuppressWarnings("deprecation")
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		TelephonyManager TelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		TelephonyMgr.listen(new TeleListener(),
				PhoneStateListener.LISTEN_CALL_STATE);
		String msg = intent.getStringExtra("Start");
		int flag = Integer.parseInt(msg);
		if (flag == 1) {

			Toast.makeText(getApplicationContext(), "Service Started",
					Toast.LENGTH_LONG).show();

			Notification notification = new Notification(
					R.drawable.ic_launcher, "WideAwake",
					System.currentTimeMillis());

			Intent main = new Intent(this, MainActivity.class);
			main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
					| Intent.FLAG_ACTIVITY_SINGLE_TOP);
			PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
					main, PendingIntent.FLAG_UPDATE_CURRENT);

			notification.setLatestEventInfo(this, "ALERT",
					"Don't answer the call while Charging", pendingIntent);
			notification.flags |= Notification.FLAG_ONGOING_EVENT
					| Notification.FLAG_FOREGROUND_SERVICE
					| Notification.FLAG_NO_CLEAR;

			startForeground(2, notification);
		}
		if (flag == 2) {
			this.stopForeground(true);

			Toast.makeText(getApplicationContext(), "Service Destroyed",
					Toast.LENGTH_LONG).show();
			return START_NOT_STICKY;
		}
		return START_STICKY;
	}

}