package srinivasaganapathi.s.wideawake;

import android.os.Bundle;
import android.widget.TextView;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

public class Aware extends Activity {
	TextView t1;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_aware);
		ActionBar acb = getActionBar();
		acb.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#3b5998")));

	}

}
